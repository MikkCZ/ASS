package alg;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author Michal Stanke <stankmic@fel.cvut.cz>
 */
public class GraphComponent<LongT extends Long> extends ArrayList<Long> {
    boolean[][] graphMatrix;
    long D;
    
    public GraphComponent(long node) {
        this.add(node);
    }
    
    public int getGraphRadius(long D) {
        this.D = D;
        if(this.size()==1) {return 0;}
        if(this.size()==2 || this.size()==3) {return 1;}
        prepareMatrix();
        int MIN = Integer.MAX_VALUE;
        for(int nodeIndex=0; nodeIndex<this.size(); nodeIndex++) {
            //int temp = getGraphRadiusForNodeIndex(nodeIndex);
            int temp = distanceBetween(nodeIndex, 0);
            if(temp<MIN) {
                MIN=temp;
            }
        }
        return MIN;
    }
    
    private void prepareMatrix() {
        graphMatrix = new boolean[this.size()][this.size()];
        for(int i=0; i<this.size(); i++) {
            for(int j=0; j<this.size(); j++) {
                if(!graphMatrix[i][j] && areConnected(this.get(i), this.get(j))) {
                    graphMatrix[i][j]=true;
                    graphMatrix[j][i]=true;
                }
            }
        }
    }
    
    private int getGraphRadiusForNodeIndex(int nodeIndex) {
        int MAX = Integer.MIN_VALUE;
        for(int otherNodeIndex=0; otherNodeIndex<this.size(); otherNodeIndex++) {
            int temp = distanceBetween(nodeIndex, otherNodeIndex);
            if(temp>MAX) {
                MAX=temp;
            }
        }
        return MAX;
    }
    
    private int distanceBetween(int nodeIndex, int otherNodeIndex) {
        boolean[] reached = new boolean[this.size()];
        reached[nodeIndex] = true;
        int counter = 0;
        Integer[] lastReached = {nodeIndex};
        
        HashSet<Integer> temp = new HashSet<Integer>();
        while(lastReached.length!=0) {
            for(int i : lastReached) {
                for(int j=0; j<this.size(); j++) {
                    if(graphMatrix[i][j] && !reached[j]) {
                        reached[j]=true;
                        temp.add(j);
                    }
                }
            }
            lastReached = temp.toArray(new Integer[0]);
            temp = new HashSet<Integer>();
            if(lastReached.length!=0) {
                counter++;
            }
        }
        return counter;
        
        //do pole A dat sebe
        //do pole B dat propojeni primo s timhle
        //do pole A dej vse z B
        
        //while v poli A nejsou vsechny
        //do pole B dej vsechny propojene primo s vsemi z A
        //do pole A pridej z B, co tam jeste neni
        //return 0;
    }
    
    private boolean areConnected(long node, long otherNode) {
        long x = node+otherNode + Math.abs(node-otherNode) + 3;
        long y = node*otherNode + Math.abs(node-otherNode) + 2;
        if(findGCD(x,y)>=D) {
            return true;
        }
        return false;
    }
    
    private static long findGCD(long a, long b) {
        long temp;
        while (b!=0) {
            temp = b;
            b = a%b;
            a = temp;
        }
        return a;
    }
    
}
