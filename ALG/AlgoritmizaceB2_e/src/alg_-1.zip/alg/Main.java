package alg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    static long D;
    static LinkedList<ArrayList<Long>> graph = new LinkedList<ArrayList<Long>>();
    static boolean[][] COMPONENT_MATRIX;
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        long N1 = input.nextLong();
        long N2 = input.nextLong();
        D = input.nextLong();
        int totalNodes = (int)(N2-N1+1);
        
        graph.add(new ArrayList<Long>(totalNodes));
        graph.get(0).add(N1);
        
        long newNode = N1;
        ArrayList<Long> newComponent;
        ArrayList<ArrayList<Long>> toRemove = new ArrayList<ArrayList<Long>>(totalNodes);
        
        do {
            newNode++;
            newComponent = new ArrayList<Long>(totalNodes);
            newComponent.add(newNode);
            toRemove.clear();
            for(ArrayList<Long> component : graph) {
                if(nodeConnectedWithComponent(newNode, component)) {
                    newComponent.addAll(component);
                    toRemove.add(component);
                }
            }
            graph.add(newComponent);
            graph.removeAll(toRemove);
        } while(newNode != N2);
        
        int maxRadius = countMaxGraphRadius();
        
        System.out.println(graph.size()+" "+maxRadius);
    }
    
    static boolean nodeConnectedWithComponent(long node, ArrayList<Long> component) {
        for(long internalNode : component) {
            if(areConnected(node, internalNode)) {
                return true;
            }
        }
        return false;
    }
    
    static boolean areConnected(long node, long otherNode) {
        long x, y;
        x = otherNode+node + Math.abs(otherNode-node) + 3;
        y = otherNode*node + Math.abs(otherNode-node) + 2;
        if(findGCD(x,y)>=D) {
            return true;
        }
        return false;
    }
    
    static long findGCD(long a, long b) {
        long temp;
        while (b!=0) {
            temp = b;
            b = a%b;
            a = temp;
        }
        return a;
    }
    
    static int countMaxGraphRadius() {
        sortGraph();
        int maxRadius = 0;
        int componentSize, componentRadius;
        for(ArrayList<Long> c : graph) {
            componentSize = c.size();
            if(componentSize/2<maxRadius || componentSize==1) {
                return maxRadius;
            }
            if(componentSize == 2 || componentSize==3) {
                componentRadius = 1;
            } else {
                componentRadius = countComponentRadius(c);
            }
            if(componentRadius>maxRadius) {
                maxRadius=componentRadius;
            }
        }
        return maxRadius;
    }
    
    static void sortGraph() {
        Collections.sort(graph, new Comparator<ArrayList>() {
            @Override
            public int compare(ArrayList o1, ArrayList o2) {
                int size1 = o1.size();
                int size2 = o2.size();
                if(size1>size2) {
                    return -1;
                } else if(size2>size1) {
                    return 1;
                }
                return 0;
            }
        });
    }
    
    static int countComponentRadius(ArrayList<Long> c) {
        int componentSize = c.size();
        COMPONENT_MATRIX = new boolean[componentSize][componentSize];
        long node;
        for(int i=0; i<componentSize; i++) {
            node = c.get(i);
            for(int j=i+1; j<componentSize; j++) {
                if(!COMPONENT_MATRIX[i][j]) {
                    if(areConnected(node, c.get(j))) {
                        COMPONENT_MATRIX[i][j] = true;
                        COMPONENT_MATRIX[j][i] = true;
                    }
                }
            }
        }
        
        int radius, minRadius = Integer.MAX_VALUE;
        for(int i=0; i<componentSize; i++) {
            radius = countComponentRadiusForIndex(componentSize, i);
            if(radius<minRadius) {
                minRadius = radius;
            }
        }
        return minRadius;
    }
    
    static int countComponentRadiusForIndex(int size, int index) {
        boolean[] reached = new boolean[size];
        reached[index] = true;
        int radius = 0;
        int[] lastReached = new int[size];
        lastReached[0] = index;
        int lIndex = 0;
        int rIndex = 1;
        int added = 0, nIndex;
        while (true) {
            for (int i = lIndex; i < rIndex; i++) {
                nIndex = lastReached[i];
                for (int j = 0; j < size; j++) {
                    if (reached[j]) {
                        continue;
                    }
                    if (COMPONENT_MATRIX[nIndex][j]) {
                        reached[j] = true;
                        lastReached[rIndex + added] = j;
                        added++;
                    }
                }
            }
            if (added == 0) {
                return radius;
            }
            lIndex = rIndex;
            rIndex += added;
            added = 0;
            radius++;
        }
    }

}
