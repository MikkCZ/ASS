package alg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
    static long D;
    static LinkedList<ArrayList<Long>> graph = new LinkedList<ArrayList<Long>>();
    static short[][] COMPONENT_MATRIX;
    static Queue QUEUE = new Queue();
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        long N1 = input.nextLong();
        long N2 = input.nextLong();
        D = input.nextLong();
        int totalNodes = (int)(N2-N1+1);
        double start = System.currentTimeMillis();
        
        graph.add(new ArrayList<Long>(totalNodes));
        graph.get(0).add(N1);
        
        long newNode = N1;
        ArrayList<Long> newComponent;
        ArrayList<ArrayList<Long>> toRemove = new ArrayList<ArrayList<Long>>(totalNodes);
        
        do {
            newNode++;
            newComponent = new ArrayList<Long>(totalNodes);
            newComponent.add(newNode);
            toRemove.clear();
            for(ArrayList<Long> component : graph) {
                if(nodeConnectedWithComponent(newNode, component)) {
                    newComponent.addAll(component);
                    toRemove.add(component);
                }
            }
            graph.add(newComponent);
            graph.removeAll(toRemove);
        } while(newNode != N2);
        
        int maxRadius = countMaxGraphRadius();
        System.out.println(System.currentTimeMillis()-start);
        
        System.out.println(graph.size()+" "+maxRadius);
    }
    
    static boolean nodeConnectedWithComponent(long node, ArrayList<Long> component) {
        for(long internalNode : component) {
            if(areConnected(node, internalNode)) {
                return true;
            }
        }
        return false;
    }
    
    static boolean areConnected(long node, long otherNode) {
        long x, y;
        x = otherNode+node + Math.abs(otherNode-node) + 3;
        y = otherNode*node + Math.abs(otherNode-node) + 2;
        if(findGCD(x,y)>=D) {
            return true;
        }
        return false;
    }
    
    static long findGCD(long a, long b) {
        long temp;
        while (b!=0) {
            temp = b;
            b = a%b;
            a = temp;
        }
        return a;
    }
    
    static int countMaxGraphRadius() {
        sortGraph();
        int maxRadius = 0;
        int componentSize, componentRadius;
        for(ArrayList<Long> c : graph) {
            componentSize = c.size();
            if(componentSize/2<maxRadius || componentSize==1) {
                break;
            }
            if(componentSize == 2 || componentSize==3) {
                componentRadius = 1;
            } else {
                componentRadius = countComponentRadius(c);
            }
            if(componentRadius>maxRadius) {
                maxRadius=componentRadius;
            }
        }
        return maxRadius;
    }
    
    static void sortGraph() {
        Collections.sort(graph, new Comparator<ArrayList>() {
            @Override
            public int compare(ArrayList o1, ArrayList o2) {
                int size1 = o1.size();
                int size2 = o2.size();
                if(size1>size2) {
                    return -1;
                } else if(size2>size1) {
                    return 1;
                }
                return 0;
            }
        });
    }
    
    static int countComponentRadius(ArrayList<Long> c) {
        int componentSize = c.size();
        COMPONENT_MATRIX = new short[componentSize][componentSize];
        for(int i=0; i<componentSize; i++) {
            countComponentMatrixForNodeIndex(c, i);
        }
        
        int radius, minRadius = Integer.MAX_VALUE;
        for(int i=0; i<componentSize; i++) {
            Arrays.sort(COMPONENT_MATRIX[i]);
            radius = COMPONENT_MATRIX[i][0];
            if(radius<minRadius) {
                minRadius = radius;
            }
        }
        return minRadius;
    }
    
    static void countComponentMatrixForNodeIndex(ArrayList<Long> c, int index) {
        int componentSize = c.size();
        COMPONENT_MATRIX[index][index] = 0;
        short radius = 1, spacer = -1;
        int next;
        long nextValue;
        QUEUE.clear();
        QUEUE.add(index);
        while(true) {
            QUEUE.add(spacer);
            next = QUEUE.popNext();
            nextValue = c.get(next);
            while(next>=0) {
                for(int i=0; i<componentSize; i++) {
                    if(COMPONENT_MATRIX[next][i]!=0) {
                        continue;
                    }
                    if(areConnected(nextValue,c.get(i))) {
                        COMPONENT_MATRIX[next][i] = radius;
                        QUEUE.add(i);
                    }
                }
                next = QUEUE.popNext();
            }
            if(QUEUE.length==0) {
                return;
            }
            radius++;
        }
    }
    
//    static int countComponentRadiusForIndex(int size, int index) {
//        boolean[] reached = new boolean[size];
//        reached[index] = true;
//        int radius = 0, spacer = -1, next;
//        QUEUE.clear();
//        QUEUE.add(index);
//        while(true) {
//            QUEUE.add(spacer);
//            next = QUEUE.popNext();
//            while(next>=0) {
//                for(int i=0; i<size; i++) {
//                    if(reached[i]) {
//                        continue;
//                    }
//                    if(COMPONENT_MATRIX[next][i]) {
//                        reached[i] = true;
//                        QUEUE.add(i);
//                    }
//                }
//                next = QUEUE.popNext();
//            }
//            if(QUEUE.length==0) {
//                return radius;
//            }
//            radius++;
//        }
//    }
    
    static class Queue{
        Element first = null;
        Element last = null;
        int length = 0;
        void clear() {
            first = null;
            last = null;
            length = 0;
        }
        void add(int value) {
            if(length==0) {
                first = new Element(value);
                last = first;
            } else {
                last.next = new Element(value);
                last = last.next;
            }
            length++;
        }
        int popNext() {
//            if(length==0) {
//                return Integer.MIN_VALUE;
//            }
            int value = first.value;
            first = first.next;
            length--;
            return value;
        }
    }
    
    static class Element{
        int value;
        Element next = null;
        Element(int value) {
            this.value = value;
        }
    }

}
