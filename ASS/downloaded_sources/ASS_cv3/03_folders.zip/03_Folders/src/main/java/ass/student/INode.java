package ass.student;

/**
 * User: Jan Stiborek, jan.stiborek@agents.felk.cvut.cz
 * Date: 2/28/12
 * Time: 1:13 PM
 */
public interface INode {

    /**
     * @return size of file or folder including all subfolders
     */
    long size();
}
