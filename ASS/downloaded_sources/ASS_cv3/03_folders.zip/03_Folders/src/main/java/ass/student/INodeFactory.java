package ass.student;

import java.io.File;

/**
 * User: Jan Stiborek, jan.stiborek@agents.felk.cvut.cz
 * Date: 2/28/12
 * Time: 2:14 PM
 */
final public class INodeFactory {

    private INodeFactory() {
    }

    public static INode newInstance(File path){
        //TODO: implement me
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
