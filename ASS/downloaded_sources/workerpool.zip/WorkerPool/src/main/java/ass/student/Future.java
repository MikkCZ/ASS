package ass.student;

public interface Future<T> {

    T get() throws Exception;
}
