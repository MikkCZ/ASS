import os

class Corpus:
    def __init__(self, folder_path):
        self.folder_path = folder_path
        
    def emails_as_string(self):
        folder_path = self.folder_path
        file_list = self.listdir_file_names(folder_path)
        
        for fname in file_list:
            file_path = folder_path + '/' + fname
            body = self.read_file_body(file_path)
            yield (fname, body)
        
    def listdir_file_names(self, folder_path):
        file_list = []
        for fname in os.listdir(folder_path):
            if not fname.startswith('!'):
                file_list.append(fname)
        return file_list

    def read_file_body(self, file_path):
        file_body = open(file_path).read()
        return file_body
        
if __name__ == "__main__":
    # Create corpus from a directory
    corpus = Corpus(r'spam-data/1')
    count = 0
    # Go through all emails and print the filename and the message body
    for fname, body in corpus.emails_as_string():
        print(fname)
        print(body)
        print('-------------------------')
        count += 1
        print('Finished: ', count, 'files processed.')
        