def quality_score(tp, tn, fp, fn):
    score = (tp + tn) / (tp + tn + 10*fp + fn)
    return score
    
def compute_quality_for_corpus(corpus_dir):
    from utils import read_classification_from_file as load_as_dict
    truth_dict = load_as_dict(corpus_dir + '/!truth.txt')
    pred_dict = load_as_dict(corpus_dir + '/!prediction.txt')
    
    from confmat import BinaryConfusionMatrix
    ConfMat = BinaryConfusionMatrix('SPAM', 'OK')
    ConfMat.compute_from_dicts(truth_dict, pred_dict)
    confusion_dict = ConfMat.as_dict()
    
    tp = confusion_dict['tp']
    tn = confusion_dict['tn']
    fp = confusion_dict['fp']
    fn = confusion_dict['fn']
    
    return quality_score(tp, tn, fp, fn)