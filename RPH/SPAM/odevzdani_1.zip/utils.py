def read_classification_from_file(file_path):
    dictionary = {}
    
    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            (fname, classification) = line.split()
            dictionary[fname] = classification
    
    return dictionary
