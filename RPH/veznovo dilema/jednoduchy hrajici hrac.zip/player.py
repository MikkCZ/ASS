# MyPlayer class and whatever signed with * is obligatory and required for the game
import random

class MyPlayer:
    # * explanation how the player plays
    '''Tento hrac generuje/losuje nahodne tahy'''
    
    # * constructor; number of iterations doesn't have to be given
    def __init__(self,payoff_matrix,number_of_iterations=0):
        self.payoff = payoff_matrix
        self.noi = number_of_iterations
        
    # * move function; returns True/False decision of the player
    def move(self):
        # result_move = random.choice([True, False])
        basket_for_drawing_moves = [True, False]
        result_move = bool(random.sample(basket_for_drawing_moves, 1))
        return(bool(result_move))
    
    # * memory of opponents previous moves returned by the game
    def record_opponents_move(self,opponent_move):
        pass
    
    